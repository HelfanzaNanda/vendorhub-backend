import 'dotenv/config';
import { DataSource } from "typeorm";

export const AppDataSource = new DataSource({
    type: 'mariadb',
    host: process.env.DATABASE_HOST,
    port: Number(process.env.DATABASE_PORT),
    username: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE_DB,
    // entities: ['dist/**/*.entity.js'],
    // migrations: ['dist/database/migrations/*.js'],

    entities: ['src/**/*.entity.ts'],
    migrations: ['src/database/migrations/*.ts'],
  
    synchronize: false,
});
